package com.hpeu.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ResourceBundle;

/**
 * 连接数据库的工具类——没有用数据源方式
 * 
 * @author 姚臣伟
 *
 */
public class JdbcUtil_back {
	public JdbcUtil_back() {}
	private static final String DRIVER;
	private static final String URL;
	private static final String USER;
	private static final String PASSWORD;
	
	static {
		ResourceBundle bundle = ResourceBundle.getBundle("db");
		
		DRIVER = bundle.getString("jdbc.driver");
		URL = bundle.getString("jdbc.url");
		USER = bundle.getString("jdbc.user");
		PASSWORD = bundle.getString("jdbc.password");
		
		// 加载驱动器类
		try {
			Class.forName(DRIVER);
		} catch (ClassNotFoundException e) {
			throw new ExceptionInInitializerError("加载驱动器类出错：" + e.getMessage());
		}
		
		/*Properties prop = new Properties();
		try {
			prop.load(JdbcUtil.class.getClassLoader().getResourceAsStream("db.properties"));
		} catch (IOException e) {
			e.printStackTrace();
		}*/
	}
	
	/**
	 * 创建连接对象
	 * @return
	 */
	public static Connection getConnection() {
		Connection conn = null;
		
		try {
			conn = DriverManager.getConnection(URL, USER, PASSWORD);
		} catch (SQLException e) {
			throw new ExceptionInInitializerError("创建连接对象出错：" + e.getMessage());
		}
		return conn;
	}
	
	/**
	 * 添加、修改、删除
	 * @param sql 执行的SQl语句
	 * @param params 参数列表
	 */
	public static void operate(String sql, Object...params) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		
		try {
			conn = getConnection();
			pstmt = conn.prepareStatement(sql);
			if (null != params && params.length > 0) {
				for(int i=0; i<params.length; i++) {
					pstmt.setObject(i+1, params[i]);
				}
			}
			pstmt.execute();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			closeAll(null, pstmt, conn);
		}
	}
	
	/**
	 * 关闭资源
	 * @param rs
	 * @param pstmt
	 * @param conn
	 */
	public static void closeAll(ResultSet rs, PreparedStatement pstmt, Connection conn) {
		if (rs != null) {
			try {
				rs.close();
			} catch (SQLException e) {
			}
		}
		if (pstmt != null) {
			try {
				pstmt.close();
			} catch (SQLException e) {
			}
		}
		if (conn != null) {
			try {
				conn.close();
			} catch (SQLException e) {
			}
		}
	}
	
	
	
}
