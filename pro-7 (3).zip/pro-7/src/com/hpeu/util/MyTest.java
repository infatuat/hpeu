package com.hpeu.util;

import java.util.UUID;

public class MyTest {

	public static void main(String[] args) {
		String uid = UUID.randomUUID().toString();
		System.out.println(uid);
	}

}
