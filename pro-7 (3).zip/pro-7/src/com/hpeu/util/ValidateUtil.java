package com.hpeu.util;

/**
 * 数据验证工具类
 * 
 * @author 姚臣伟
 */
public class ValidateUtil {
	private ValidateUtil() {}
	
	/**
	 * 验证指定的字符串是否有效
	 * @param str 被验证的字符串
	 * @param reg 正则表达式
	 * @return    返回：true表示验证成功，false验证失败
	 */
	public static boolean validate(String str, String reg) {
		if (null == str || "".equals(str.trim())) {
			return false;
		}
		return str.matches(reg);
	}
	
	/**
	 * 验证指定的数字是否有效
	 * @param str 被验证的数字
	 * @return    返回：true表示验证成功，false验证失败
	 */
	public static boolean validate(Integer num) {
		if (null == num || num < 0) {
			return false;
		}
		return true;
	}
	
	/**
	 * 字符串转数字
	 * @param num 待转换的字符串
	 * @return 返回转换后的数字
	 */
	public static int stringToInt(String num) {
		if (validate(num, "^\\d+$")) {
			return Integer.parseInt(num);
		}
		return 0;
	}
	
	
}
