package com.hpeu.util;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Properties;

import javax.sql.DataSource;

import com.alibaba.druid.pool.DruidDataSource;

/**
 * 连接数据库的工具类——使用（阿里的）数据源连接池
 * 
 * @author 姚臣伟
 *
 */
public class JdbcUtil {
	public JdbcUtil() {}
	//private static DataSource dataSource = null;
	private static DruidDataSource dataSource = null;
	static {
		try {
			Properties prop = new Properties();
			prop.load(JdbcUtil.class.getClassLoader().getResourceAsStream("db.properties"));
			
			//System.out.println(prop.get("jdbc.driver"));
			
			
			// 创建数据源连接池
			//dataSource = DruidDataSourceFactory.createDataSource(prop);
			dataSource = new DruidDataSource();
			dataSource.setDriverClassName((String)prop.get("jdbc.driver"));
			dataSource.setUrl((String)prop.get("jdbc.url"));
			dataSource.setUsername((String)prop.get("jdbc.user"));
			dataSource.setPassword((String)prop.get("jdbc.password"));
		} catch (Exception e) {
			throw new ExceptionInInitializerError("加载驱动器类出错：" + e.getMessage());
		}
	}
	
	/**
	 * 返回数据源对象
	 * 
	 * @return
	 */
	public static DataSource getDataSource() {
		return dataSource;
	}
	
	/**
	 * 创建连接对象
	 * @return
	 */
	public static Connection getConnection() {
		Connection conn = null;
		
		try {
			conn = dataSource.getConnection();
		} catch (SQLException e) {
			throw new ExceptionInInitializerError("创建连接对象出错：" + e.getMessage());
		}
		return conn;
	}
	
	/**
	 * 添加、修改、删除
	 * @param sql 执行的SQl语句
	 * @param params 参数列表
	 */
	public static void operate(String sql, Object...params) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		
		try {
			conn = getConnection();
			pstmt = conn.prepareStatement(sql);
			if (null != params && params.length > 0) {
				for(int i=0; i<params.length; i++) {
					pstmt.setObject(i+1, params[i]);
				}
			}
			pstmt.execute();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			closeAll(null, pstmt, conn);
		}
	}
	
	/**
	 * 关闭资源
	 * @param rs
	 * @param pstmt
	 * @param conn
	 */
	public static void closeAll(ResultSet rs, PreparedStatement pstmt, Connection conn) {
		if (rs != null) {
			try {
				rs.close();
			} catch (SQLException e) {
			}
		}
		if (pstmt != null) {
			try {
				pstmt.close();
			} catch (SQLException e) {
			}
		}
		if (conn != null) {
			try {
				conn.close();
			} catch (SQLException e) {
			}
		}
	}
}
