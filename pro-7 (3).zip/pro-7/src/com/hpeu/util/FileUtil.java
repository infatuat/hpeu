package com.hpeu.util;

import java.util.Random;
import java.util.UUID;

/**
 * 文件操作工具类
 * @author 姚臣伟
 */
public class FileUtil {
	private FileUtil() {}
	
	/**
	 * 从指定字符串中获取文件名称
	 * @param str 字符串
	 * @return 返回文件名称
	 */
	public static String getFileName(String str) {
		if (null == str || "".equals(str.trim())) {
			return "";
		}
		// form-data; name="upfile"; filename="102.jpg"
		
		String tmp = "filename=";
		int p = str.indexOf(tmp);
		if (p != -1) {
			p = p + tmp.length() + 1;
		}
		return str.substring(p, str.length()-1);
	}
	
	/**
	 * 根据文件的mime类型返回文件扩展名称
	 * @param mimeType mime类型
	 * @return 返回文件扩展名称
	 */
	public static String getFileExt(String mimeType) {
		switch (mimeType) {
			case "image/jpeg":
				return ".jpg";
			case "image/png":
				return ".png";
			case "image/gif":
				return ".gif";
		}
		return "";
	}
	
	/**
	 * 生成不会重复的文件名称
	 * @param ext 文件的扩展名
	 * @return 返回文件名称
	 */
	public static String createFileName(String ext) {
		String str = UUID.randomUUID().toString();
		return str.replaceAll("-", "") + ext;
	}
	
	/**
	 * 生成不会重复的文件名称
	 * @param ext 文件的扩展名
	 * @return 返回文件名称
	 */
	public static String createFileName2(String ext) {
		long date = System.currentTimeMillis();
		int rand = new Random().nextInt(9999);
		return date + "" + rand + ext;
	}
	


	
	
	
}
