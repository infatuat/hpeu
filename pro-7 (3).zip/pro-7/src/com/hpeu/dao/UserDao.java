package com.hpeu.dao;

import java.util.List;

import com.hpeu.bean.User;

/**
 * 用户数据访问层接口类
 * 
 * @author 姚臣伟
 */
public interface UserDao {
	/**
	 * 添加用户
	 * @param user 用户对象
	 */
	public void saveUser(User user);
	/**
	 * 根据用户编号删除用户信息
	 * @param id 用户编号
	 */
	public void removeUser(Integer id);
	/**
	 * 修改用户
	 * @param user 用户对象
	 */
	public void modifyUser(User user);
	/**
	 * 根据用户编号查询用户信息
	 * @param id 用户编号
	 * @return  返回查询用户信息
	 */
	public User getUserById(Integer id);
	/**
	 * 查询全部用户信息
	 * @param pagesize 每页显示记录数
	 * @param page     当前页码
	 * @return 返回全部用户信息
	 */
	public List<User> getUsers(int page, int pagesize);
	/**
	 * 查询用户总记录数
	 * @return 返回用户总记录数
	 */
	public long getCount();
	/**
	 * 用户登录
	 * @param username 账号
	 * @param password 密码
	 * @return	返回是否存在，大于0存在，否则不存在
	 */
	public long login(String username, String password);
	/**
	 * 判断账号是否存在
	 * @param account 账号
	 * @return true：存在；false：不存在
	 */
	public long checkUserByAccount(String account);
}
