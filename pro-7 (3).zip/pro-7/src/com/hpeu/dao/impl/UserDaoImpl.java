package com.hpeu.dao.impl;

import java.sql.SQLException;
import java.util.List;

import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.BeanHandler;
import org.apache.commons.dbutils.handlers.BeanListHandler;
import org.apache.commons.dbutils.handlers.ScalarHandler;

import com.hpeu.bean.User;
import com.hpeu.dao.UserDao;
import com.hpeu.util.JdbcUtil;

/**
 * 用户数据访问层接口实现类
 * 
 * @author 姚臣伟
 */
public class UserDaoImpl implements UserDao {
	private QueryRunner runner = new QueryRunner(JdbcUtil.getDataSource());

	/**
	 * 添加用户
	 * @param user 用户对象
	 */
	@Override
	public void saveUser(User user) {
		String sql = "INSERT INTO tb_user(name,account,password,email,phone,regtime,avator) VALUES(?,?,?,?,?,?,?)";
		/*JdbcUtil.operate(sql, user.getName(),user.getAccount(),
				user.getPassword(),user.getEmail(),
				user.getPhone(),new java.sql.Date(user.getRegtime().getTime()));*/
		try {
			runner.update(sql, user.getName(),user.getAccount(),
					user.getPassword(),user.getEmail(),
					user.getPhone(),new java.sql.Date(user.getRegtime().getTime()),user.getAvator());
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	/**
	 * 根据用户编号删除用户信息
	 * @param id 用户编号
	 */
	@Override
	public void removeUser(Integer id) {
		String sql = "DELETE FROM tb_user WHERE id=?";
		/*JdbcUtil.operate(sql, id);*/
		try {
			runner.update(sql, id);
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	/**
	 * 修改用户
	 * @param user 用户对象
	 */
	@Override
	public void modifyUser(User user) {
		String sql = "UPDATE tb_user SET name=?,account=?,password=?,email=?,phone=? WHERE id=?";
		/*JdbcUtil.operate(sql, user.getName(),user.getAccount(),
				user.getPassword(),user.getEmail(),
				user.getPhone(),user.getId());*/
		
		try {
			runner.update(sql, user.getName(),user.getAccount(),
					user.getPassword(),user.getEmail(),
					user.getPhone(),user.getId());
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	/**
	 * 根据用户编号查询用户信息
	 * @param id 用户编号
	 * @return  返回查询用户信息
	 */
	@Override
	public User getUserById(Integer id) {
		String sql = "SELECT * FROM tb_user WHERE id=?";
		
		try {
			User user = runner.query(sql, new BeanHandler<User>(User.class), id);
			return user;
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
		
		/*Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		User user = null;
		
		try {
			conn = JdbcUtil.getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, id);
			rs = pstmt.executeQuery();
			if (rs.next()) {
				user = new User();
				user.setId(rs.getInt("id"));
				user.setName(rs.getString("name"));
				user.setAccount(rs.getString("account"));
				user.setEmail(rs.getString("email"));
				user.setPhone(rs.getString("phone"));
				user.setRegtime(rs.getDate("regtime"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			JdbcUtil.closeAll(rs, pstmt, conn);
		}
		
		return user;*/
	}
	/**
	 * 查询全部用户信息
	 * @param pagesize 每页显示记录数
	 * @param page     当前页码
	 * @return 返回全部用户信息
	 */
	@Override
	public List<User> getUsers(int page, int pagesize) {
		String sql = "SELECT * FROM tb_user LIMIT ?,?";
		
		page = (page - 1)* pagesize;
		System.out.println("--------- page = " + page);
		
		try {
			List<User> users = runner.query(sql, new BeanListHandler<User>(User.class), page, pagesize);
		
			return users;
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
		
		/*Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		List<User> users = null;
		
		try {
			conn = JdbcUtil.getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, (page - 1)*pagesize);
			pstmt.setInt(2, pagesize);
			rs = pstmt.executeQuery();
			users = new ArrayList<>();
			while (rs.next()) {
				User user = new User();
				user.setId(rs.getInt("id"));
				user.setName(rs.getString("name"));
				user.setAccount(rs.getString("account"));
				user.setEmail(rs.getString("email"));
				user.setPhone(rs.getString("phone"));
				user.setRegtime(rs.getDate("regtime"));
				users.add(user);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			JdbcUtil.closeAll(rs, pstmt, conn);
		}
		
		return users;*/
	}
	/**
	 * 查询用户总记录数
	 * @return 返回用户总记录数
	 */
	@Override
	public long getCount() {
		String sql = "SELECT count(*) FROM tb_user";
		
		try {
			return runner.query(sql, new ScalarHandler<>());
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return 0;
		
		
		/*Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		int count = 0;
		
		try {
			conn = JdbcUtil.getConnection();
			pstmt = conn.prepareStatement(sql);
			rs = pstmt.executeQuery();
			if (rs.next()) {
				count = rs.getInt(1);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			JdbcUtil.closeAll(rs, pstmt, conn);
		}
		
		return count;*/
	}
	/**
	 * 用户登录
	 * @param username 账号
	 * @param password 密码
	 * @return	返回是否存在，大于0存在，否则不存在
	 */
	@Override
	public long login(String username, String password) {
		String sql = "SELECT count(*) FROM tb_user WHERE account=? AND password=?";
		try {
			return runner.query(sql, new ScalarHandler<>(), username, password);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return 0L;
	}
	/**
	 * 判断账号是否存在
	 * @param account 账号
	 * @return true：存在；false：不存在
	 */
	public long checkUserByAccount(String account) {
		String sql = "SELECT count(*) FROM tb_user WHERE account=?";
		try {
			return runner.query(sql, new ScalarHandler<>(), account);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return 0L;
	}

}
