package com.hpeu.service.impl;

import java.util.List;

import com.hpeu.bean.User;
import com.hpeu.dao.UserDao;
import com.hpeu.dao.impl.UserDaoImpl;
import com.hpeu.service.UserService;
import com.hpeu.util.PaginationUtil;
/**
 * 用户业务逻辑层接口实现类
 * 
 * @author 姚臣伟
 */
public class UserServiceImpl implements UserService {
	private UserDao userDao = new UserDaoImpl();
	
	/**
	 * 添加或修改用户
	 * @param user 用户对象
	 */
	@Override
	public void saveOrUpdateUser(User user) {
		if (null != user.getId()) {
			userDao.modifyUser(user);
		} else {
			userDao.saveUser(user);
		}
	}
	/**
	 * 根据用户编号删除用户信息
	 * @param id 用户编号
	 */
	@Override
	public void removeUser(Integer id) {
		userDao.removeUser(id);
	}
	/**
	 * 根据用户编号查询用户信息
	 * @param id 用户编号
	 * @return  返回查询用户信息
	 */
	@Override
	public User getUserById(Integer id) {
		return userDao.getUserById(id);
	}
	/**
	 * 查询全部用户信息
	 * @param pagesize 每页显示记录数
	 * @param page     当前页码
	 * @return 返回全部用户信息
	 */
	@Override
	public PaginationUtil<User> getUsers(int page, int pagesize) {
		if (page <= 1 ) {
			page = 1;
		}
		int count = (int)userDao.getCount();
		int pages = count % pagesize == 0 ? count / pagesize : count / pagesize + 1;
		if (page > pages) {
			page = pages;
		}
		
		List<User> users = userDao.getUsers(page, pagesize);
		
		PaginationUtil<User> pg = new PaginationUtil<>(users, count, page, pagesize);
		return pg;
	}
	/**
	 * 查询用户总记录数
	 * @return 返回用户总记录数
	 */
	@Override
	public long getCount() {
		return userDao.getCount();
	}
	/**
	 * 用户登录
	 * @param username 账号
	 * @param password 密码
	 * @return	返回是否存在，true存在；false不存在
	 */
	@Override
	public boolean login(String username, String password) {
		int num = (int)userDao.login(username, password);
		return num == 0 ? false : true;
	}
	/**
	 * 判断账号是否存在
	 * @param account 账号
	 * @return true：存在；false：不存在
	 */
	public boolean checkUserByAccount(String account) {
		int num = (int)userDao.checkUserByAccount(account);
		return num == 0 ? false : true;
	}
}
