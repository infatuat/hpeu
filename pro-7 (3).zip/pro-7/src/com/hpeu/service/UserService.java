package com.hpeu.service;

import com.hpeu.bean.User;
import com.hpeu.util.PaginationUtil;

/**
 * 用户业务逻辑层接口类
 * 
 * @author 姚臣伟
 */
public interface UserService {
	/**
	 * 添加或修改用户
	 * @param user 用户对象
	 */
	public void saveOrUpdateUser(User user);
	/**
	 * 根据用户编号删除用户信息
	 * @param id 用户编号
	 */
	public void removeUser(Integer id);
	/**
	 * 根据用户编号查询用户信息
	 * @param id 用户编号
	 * @return  返回查询用户信息
	 */
	public User getUserById(Integer id);
	/**
	 * 查询全部用户信息
	 * @param pagesize 每页显示记录数
	 * @param page     当前页码
	 * @return 返回全部用户信息
	 */
	public PaginationUtil<User> getUsers(int page, int pagesize);
	/**
	 * 查询用户总记录数
	 * @return 返回用户总记录数
	 */
	public long getCount();
	/**
	 * 用户登录
	 * @param username 账号
	 * @param password 密码
	 * @return	返回是否存在，true存在；false不存在
	 */
	public boolean login(String username, String password);
	/**
	 * 判断账号是否存在
	 * @param account 账号
	 * @return true：存在；false：不存在
	 */
	public boolean checkUserByAccount(String account);
}
