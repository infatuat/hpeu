package com.hpeu.form;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

import com.hpeu.util.ValidateUtil;

/**
 * 用于验证Form表单数据
 * 
 * @author 姚臣伟
 */
public class UserFormValidate implements Serializable {
	private static final long serialVersionUID = -3964400881940326790L;
	private String name; // 姓名
	private String account; // 账号
	private String password; // 密码
	private String email; // 邮箱
	private String phone; // 电话
	
	private Map<String, String> msg = new HashMap<>(); // 用于记录验证错误信息
	
	public void validate() {
		if (!ValidateUtil.validate(this.name, "^[\\u4e00-\\u9fa5]{2,10}$")) {
			msg.put("name", "姓名不能为空或只能是中文。");
		}
		if (!ValidateUtil.validate(this.account, "^\\w{4,16}$")) {
			msg.put("account", "账号格式不对，由4到16个字母、数字和下划线组成");
		}
		if (!ValidateUtil.validate(this.password, "^\\w{6,16}$")) {
			msg.put("password", "密码格式不对，由4到16个字母、数字和下划线组成");
		}
		if (!ValidateUtil.validate(this.email, "^\\w+@\\w+(\\.[a-zA-Z]{2,3}){1,2}$")) {
			msg.put("email", "邮箱为空或格式不对，如：abc@163.com");
		}
		if (!ValidateUtil.validate(this.phone, "^1\\d{10}$")) {
			msg.put("phone", "手机号为空或格式不对，如：13855696312");
		}
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getAccount() {
		return account;
	}

	public void setAccount(String account) {
		this.account = account;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public Map<String, String> getMsg() {
		return msg;
	}

}
