package com.hpeu.web.servlet;

import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.beanutils.BeanUtils;

import com.hpeu.bean.User;
import com.hpeu.form.UserFormValidate;
import com.hpeu.service.UserService;
import com.hpeu.service.impl.UserServiceImpl;

/**
 * 处理用户信息修改
 * 
 * @author 姚臣伟
 */
@WebServlet("/eidtUserHandler")
public class UserEditHandlerServlet extends HttpServlet {
	private UserService userService = new UserServiceImpl();
	
	private static final long serialVersionUID = 8751671741138550934L;
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// 处理中文乱码
		request.setCharacterEncoding("utf-8");
		
		// 创建数据验证对象
		UserFormValidate userForm = new UserFormValidate();
		// 获取验证集合
		Map<String, String> msg = userForm.getMsg();
		msg.clear();
		
		try {
			// 对UserFormValidate赋值
			BeanUtils.populate(userForm, request.getParameterMap());
		} catch (IllegalAccessException | InvocationTargetException e1) {
			e1.printStackTrace();
		}
		// 对数据进行验证
		userForm.validate();
		
		// 获取项目名称
		String realPath = request.getServletContext().getContextPath();
		
		// 判断是否有不合法的数据
		if (!msg.isEmpty()) {
			request.setAttribute("msg", msg);
			request.getRequestDispatcher("/editUser?id=1").forward(request, response);
			return;
		}
		
		// 创建用户对象
		User user = new User();
		
		try {
			BeanUtils.populate(user, request.getParameterMap());
		} catch (IllegalAccessException | InvocationTargetException e) {
			e.printStackTrace();
		}
		
		// 添加用户
		userService.saveOrUpdateUser(user);
		
		// 添加成功后，重定向到用户列表页
		response.sendRedirect(realPath + "/list");
		return;
	}
}
