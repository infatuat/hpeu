package com.hpeu.web.servlet;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.hpeu.service.UserService;
import com.hpeu.service.impl.UserServiceImpl;
import com.hpeu.util.ValidateUtil;

/**
 * 用户登录
 * @author 姚臣伟
 */
@WebServlet("/login")
public class UserLoginServlet extends HttpServlet {
	private static final long serialVersionUID = -6959316690347126696L;
	
	private UserService userService = new UserServiceImpl();
	
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		// 处理乱码
		request.setCharacterEncoding("utf-8");
		
		// 用户存放验证信息
		Map<String, String> msg = new HashMap<>();
		msg.clear();
		
		// 创建Session对象
		HttpSession session = request.getSession();
		
		// 接收参数
		String username = request.getParameter("username");
		String password = request.getParameter("password");
		String vcode = request.getParameter("vcode");
		
		String usernameReg = "^\\w{6,16}$";
		String passwordReg = "^\\w{6,16}$";
		String vcodeReg = "^[a-zA-Z0-9]{5}$";
		
		if (!ValidateUtil.validate(username, usernameReg)) {
			msg.put("username", username);
			msg.put("userTip", "账号应该6~16位字母、数字、下划线");
		}
		if (!ValidateUtil.validate(password, passwordReg)) {
			msg.put("pwdTip", "密码应该6~16位字母、数字、下划线");
		}
		if (!ValidateUtil.validate(vcode, vcodeReg)) {
			msg.put("codeTip", "验证码应该5位");
		} else {
			// 获取session中的验证码
			String code = (String) session.getAttribute("vcode");
			if (!vcode.equalsIgnoreCase(code)) {
				msg.put("username", username);
				msg.put("vcode", vcode);
				msg.put("codeTip", "验证码不对，请重新输入。");
				//session.removeAttribute("vcode");
			}
		}
		
		// 判断Map集合中是否有数据，如果有表示有错误，则需要转发到登录页重新登录。
		// 如果没有数据，表示数据验证通过。进入登录操作
		if (!msg.isEmpty()) {
			request.setAttribute("msg", msg);
			// 转发
			request.getRequestDispatcher("/admin/login.jsp").forward(request, response);
			return;
		}
		
		boolean flag = userService.login(username, password);
		if (flag) {
			// 登录成功
			//第一步：把验证码从session中删除
			session.removeAttribute("vcode");
			// 第二步：把登录信息存放到session中
			session.setAttribute("username", username);
			
			response.sendRedirect(this.getServletContext().getContextPath() + "/admin/index.jsp");
			return;
		} else {
			// 登录失败
			msg.put("userTip", "用户名或密码错误。");
			msg.put("username", username);
			msg.put("vcode", vcode);
			request.setAttribute("msg", msg);
			request.getRequestDispatcher("/admin/login.jsp").forward(request, response);
			return;
		}
	}
}
