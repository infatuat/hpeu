package com.hpeu.web.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.hpeu.bean.User;
import com.hpeu.service.UserService;
import com.hpeu.service.impl.UserServiceImpl;
import com.hpeu.util.ValidateUtil;

/**
 * 修改用户并转到修改页面
 * 
 * @author 姚臣伟
 */
@WebServlet("/editUser")
public class UserEditServlet extends HttpServlet {
	private static final long serialVersionUID = 6185544506855966199L;
	
	private UserService userService = new UserServiceImpl();
	
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		// 接收参数
		String idStr = request.getParameter("id");
		Integer id = ValidateUtil.stringToInt(idStr);
		
		// 根据用户编号查询用户
		User user = userService.getUserById(id);
		request.setAttribute("user", user);
		
		// 转到到修改页面
		request.getRequestDispatcher("/admin/user_edit.jsp").forward(request, response);
		return;
		
	}
}
