package com.hpeu.web.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.hpeu.service.UserService;
import com.hpeu.service.impl.UserServiceImpl;
import com.hpeu.util.ValidateUtil;

/**
 * 异常请求并查询账号是否存在
 * 
 * @author 姚臣伟
 */
@WebServlet("/checkAccountExist")
public class UserCheckServlet extends HttpServlet {
	private static final long serialVersionUID = 4490741539613404250L;
	
	private UserService userService = new UserServiceImpl();
	
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		// 接收参数
		String account = request.getParameter("account");
		
		String accountReg = "^\\w{6,16}$";
		if (ValidateUtil.validate(account, accountReg)) {
			boolean flag = userService.checkUserByAccount(account);
			
			response.getWriter().write(flag+"");
			
			return;
		}
	}
}
