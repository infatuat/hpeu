package com.hpeu.web.servlet;

import java.io.File;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.util.Date;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

import org.apache.commons.beanutils.BeanUtils;

import com.hpeu.bean.User;
import com.hpeu.form.UserFormValidate;
import com.hpeu.service.UserService;
import com.hpeu.service.impl.UserServiceImpl;
import com.hpeu.util.FileUtil;

/**
 * 添加用户Servlet
 * 
 * @author 姚臣伟
 */
@WebServlet("/addUser")
@MultipartConfig
public class UserAddServlet extends HttpServlet {
	private UserService userService = new UserServiceImpl();
	
	private static final long serialVersionUID = 8751671741138550934L;
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// 处理中文乱码
		request.setCharacterEncoding("utf-8");
		
		// 创建数据验证对象
		UserFormValidate userForm = new UserFormValidate();
		// 获取验证集合
		Map<String, String> msg = userForm.getMsg();
		msg.clear();
		
		try {
			// 对UserFormValidate赋值
			BeanUtils.populate(userForm, request.getParameterMap());
		} catch (IllegalAccessException | InvocationTargetException e1) {
			e1.printStackTrace();
		}
		// 对数据进行验证
		userForm.validate();
		
		// 获取项目名称
		String realPath = request.getServletContext().getContextPath();
		
		// 判断是否有不合法的数据
		if (!msg.isEmpty()) {
			request.setAttribute("userForm", userForm);
			request.getRequestDispatcher("/admin/add.jsp").forward(request, response);
			return;
		}
		
		// 创建用户对象
		User user = new User();
		
		try {
			BeanUtils.populate(user, request.getParameterMap());
		} catch (IllegalAccessException | InvocationTargetException e) {
			e.printStackTrace();
		}
		// 添加用户注册日期
		user.setRegtime(new Date());
		
		
		/*--------------- 处理文件上传开始 ------------------*/
		Part part = request.getPart("avator");
		if (null != part && part.getSize() > 0) {
			// 得到文件mime类型
			String mime = part.getContentType();
			// 根据mime类型生成文件扩展名称
			String fileExt = FileUtil.getFileExt(mime);
			// 根据扩展名来生成文件名称
			String fileName = FileUtil.createFileName2(fileExt);
			
			// 创建一个目录用户存放上传文件
			String path = this.getServletContext().getRealPath("/upload");
			File dir = new File(path);
			if (!dir.exists()) {
				dir.mkdirs();
			}
			
			// 执行文件上传
			part.write(path + "/" + fileName);
			
			// 设置用户头像数据
			user.setAvator("upload/" + fileName);
		}
		/*--------------- 处理文件上传结束 ------------------*/
		
		// 添加用户
		userService.saveOrUpdateUser(user);
		
		// 添加成功后，重定向到用户列表页
		response.sendRedirect(realPath + "/list");
		return;
	}
}
