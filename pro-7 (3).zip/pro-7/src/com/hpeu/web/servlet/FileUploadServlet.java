package com.hpeu.web.servlet;

import java.io.File;
import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

import com.hpeu.util.FileUtil;

/**
 * 文件上传
 * 
 * @author 姚臣伟
 */
@WebServlet("/upload")
@MultipartConfig // 该注解是支持文件上传
public class FileUploadServlet extends HttpServlet {
	private static final long serialVersionUID = 7645723877752719686L;
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		// 接收参数
		String name = request.getParameter("name");
		System.out.println("name = " + name);
		
		// 获取上传文件对象
		Part part = request.getPart("upfile");
		
		String contentType = part.getContentType();
		System.out.println("contentType = " + contentType);
		
		String ext = FileUtil.getFileExt(contentType);
		System.out.println("ext = " + ext);
		
		String name2 = part.getName();
		System.out.println("name2 = " + name2);
		
		long size = part.getSize();
		System.out.println("文件大小为：" + size);
		
		String header = part.getHeader("Content-Disposition");
		// form-data; name="upfile"; filename="102.jpg"
		System.out.println(header);
		
		System.out.println(FileUtil.getFileName(header));
		
		System.out.println("------------------");
		
		System.out.println(FileUtil.createFileName(ext));
		
		String fn = FileUtil.createFileName2(ext);
		System.out.println(fn);
		
		// 创建一个目录用户存放上传文件
		String path = this.getServletContext().getRealPath("/upload");
		File dir = new File(path);
		if (!dir.exists()) {
			dir.mkdirs();
		}
		
		part.write(path + "/" + fn);
		
	}
}
