package com.hpeu.web.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.hpeu.service.UserService;
import com.hpeu.service.impl.UserServiceImpl;
import com.hpeu.util.ValidateUtil;

/**
 * 删除用户Servlet
 * 
 * @author 姚臣伟
 */
@WebServlet("/userDel")
public class UserDelServlet extends HttpServlet {
	private static final long serialVersionUID = 4045942615415747511L;
	
	private UserService userService = new UserServiceImpl();
	
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		// 接收参数
		String idStr = request.getParameter("id");
		String pageStr = request.getParameter("page");
		
		Integer id = ValidateUtil.stringToInt(idStr);
		Integer page = ValidateUtil.stringToInt(pageStr);
		
		if (id >= 1) {
			
			// 执行删除操作
			userService.removeUser(id);
		}
		
		// 重定向到用户列表
		String path = this.getServletContext().getContextPath();
		response.sendRedirect(path + "/list?page=" + page);
		return;
		
	}
}
