package com.hpeu.web.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import cn.dsna.util.images.ValidateCode;

/**
 * 生成验证码
 * 
 * @author 姚臣伟
 */
@WebServlet("/vcode")
public class ValidateCodeServlet extends HttpServlet {
	private static final long serialVersionUID = 5539265296679269471L;
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		// 使用第三方程序来生成验证码
		ValidateCode code = new ValidateCode(200, 40);
		
		// 获取生成的验证码内容字符串
		String s = code.getCode();
		// 把生成的验证码内容存入session对象，用于登录判断
		request.getSession().setAttribute("vcode", s);
		
		// 输出到客户端
		code.write(response.getOutputStream());
	}
}
