package com.hpeu.web.servlet;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.hpeu.bean.User;
import com.hpeu.service.UserService;
import com.hpeu.service.impl.UserServiceImpl;
import com.hpeu.util.PaginationUtil;
import com.hpeu.util.ValidateUtil;

/**
 * 用户列表
 * 
 * @author 姚臣伟
 */
@WebServlet("/list")
public class UserListServlet extends HttpServlet {
	private static final long serialVersionUID = 737471150109434390L;
	
	private UserService userService = new UserServiceImpl();
	
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		// 接收页码参数
		String pageStr = request.getParameter("page");
		// 把字符串的页码转换为字数的字码
		Integer page = ValidateUtil.stringToInt(pageStr);
		if (page <= 1) {
			page = 1;
		}
		
		int pagesize = 3;
		
		// 根据分页查询用户列表
		PaginationUtil<User> users = userService.getUsers(page, pagesize);
		
		List<User> items = users.getItems();
		for (User user : items) {
			System.out.println(user.getAccount() + "   " + user.getAvator());
		}
		
		// 把查询到的用户放到request作用范围
		request.setAttribute("users", users);
		request.setAttribute("page", page);
		
		// 把查询到的数据带到list.jsp页面中
		request.getRequestDispatcher("/admin/user_list.jsp").forward(request, response);
		
		return;
		
	}
}
