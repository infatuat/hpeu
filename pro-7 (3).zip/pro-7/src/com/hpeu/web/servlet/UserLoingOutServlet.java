package com.hpeu.web.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * 用户退出
 * 
 * @author 姚臣伟
 */
@WebServlet("/loginout")
public class UserLoingOutServlet extends HttpServlet {
	private static final long serialVersionUID = 1028756933614136906L;
	
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		// 创建session对象
		HttpSession session = request.getSession();
		
		// 清楚session对象
		session.invalidate();
		
		// 重定向到登录页面
		response.sendRedirect(this.getServletContext().getContextPath() + "/admin/login.jsp");
		
		return;
		
	}
}
